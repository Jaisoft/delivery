#!/bin/bash

DATE=$(date +%Y%m%d)
echo $DATE 


OF=my_file_$(date +%Y%m%d).tar.gz
tar -czf $OF /Users/jaisoft/Documents/bashScriptProjects

ls



