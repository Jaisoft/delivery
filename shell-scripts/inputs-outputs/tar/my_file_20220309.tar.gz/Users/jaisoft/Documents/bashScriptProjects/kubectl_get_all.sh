#!/bin/bash

kubectl_get_all(){

    kubectl get all
}


kubectl_get_all