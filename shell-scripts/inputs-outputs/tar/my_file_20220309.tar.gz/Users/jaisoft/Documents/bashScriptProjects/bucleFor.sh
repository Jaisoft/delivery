#!/bin/bash

for i in 1 2 3 4 5

do 

	echo "Hello $i"

done




for ((c=1; c<=5; c++))
do
	echo "Hola $c"
done
