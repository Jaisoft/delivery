#!/bin/bash
greetings="Hello World"

echo $greetings