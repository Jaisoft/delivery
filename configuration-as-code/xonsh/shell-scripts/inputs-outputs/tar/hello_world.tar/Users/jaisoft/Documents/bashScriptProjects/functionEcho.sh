#!/bin/bash


hello_world(){

    echo "Hello World"
}



hello_world
