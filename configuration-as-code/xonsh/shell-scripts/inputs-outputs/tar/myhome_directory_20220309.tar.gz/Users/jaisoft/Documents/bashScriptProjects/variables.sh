#!/bin/bash
OF=myhome_directory_$(date +%Y%m%d).tar.gz
tar -czf $OF /Users/jaisoft/Documents/bashScriptProjects 